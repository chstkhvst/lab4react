// import React, { useContext } from "react"
// import { REObjectContext } from "../context/REObjectContext"
// import { Link, useNavigate } from "react-router-dom"


// // Компонент для отображения списка объектов
// const REObjectList: React.FC = () => {
//   const context = useContext(REObjectContext) // Получаем доступ к глобальному состоянию из контекста
//   const navigate = useNavigate() // Хук для программной навигации между страницами


//   if (!context) return <div>No context available!</div>


//   const { reobjects, deleteREObject } = context

//   const handleDelete = (id: number) => {
//     const isConfirmed = window.confirm("Are you sure you want to delete this project?")
//     if (isConfirmed) {
//       deleteREObject(id) // Удаляем проект, если пользователь подтвердил действие
//     }
//   }

//   return (
//     <div>
//       <h2>REObjects</h2>
//       {/* Кнопка для добавления нового объекта */}  
//       <button onClick={() => navigate("reobjects/add")}>Add New Object</button>


//       {/* Отображение списка объекта */}
//       {reobjects.map((reobject) => (
//           <p key={reobject.id}>
//             <h2>
//               {`${reobject.street}, д. ${reobject.building}${
//                 reobject.roomnum ? `, кв. ${reobject.roomnum}` : ""
//               }`}
//             </h2>
//             <p>
//               Площадь: {reobject.square} м² | Этажей: {reobject.floors} | Комнат:{" "}
//               {reobject.rooms}
//             </p>
//             <p>Цена: {reobject.price} руб.</p>
//             <Link to={`/reobjects/${reobject.id}`}>Подробнее</Link>
//             <button onClick={() => handleDelete(reobject.id)}>Delete</button> {/* Удаление  */}
//           </p>
//         ))}
//     </div>
//   )
// }


// export default REObjectList
import React from "react";
import { Link, useNavigate } from "react-router-dom";

interface REObject {
  id: number;
  street: string;
  building: string;
  roomnum?: string;
  rooms: number;
  floors: number;
  square: number;
  price: number;
}

interface Props {
  objects: REObject[];
  onDelete?: (id: number) => void;
}

const REObjectList: React.FC<Props> = ({ objects, onDelete }) => {
  const navigate = useNavigate();

  const handleDelete = (id: number) => {
    const isConfirmed = window.confirm("Вы уверены, что хотите удалить объект?");
    if (isConfirmed && onDelete) {
      onDelete(id);
    }
  };

  return (
    <div>
      {objects.map((reobject) => (
        <div key={reobject.id} style={{ 
          border: '1px solid #ccc',
          padding: '15px',
          marginBottom: '10px',
          borderRadius: '5px'
        }}>
          <h3>
            {`${reobject.street}, д. ${reobject.building}${
              reobject.roomnum ? `, кв. ${reobject.roomnum}` : ""
            }`}
          </h3>
          <p>Площадь: {reobject.square} м²</p>
          <p>Этажей: {reobject.floors} | Комнат: {reobject.rooms}</p>
          <p>Цена: {reobject.price.toLocaleString()} руб.</p>
          
          <div style={{ marginTop: '10px' }}>
            <Link 
              to={`/reobjects/${reobject.id}`} 
              style={{ marginRight: '10px', textDecoration: 'none' }}
            >
              Подробнее
            </Link>
            
            {onDelete && (
              <button 
                onClick={() => handleDelete(reobject.id)}
                style={{ 
                  backgroundColor: '#ff4444',
                  color: 'white',
                  border: 'none',
                  padding: '5px 10px',
                  borderRadius: '3px',
                  cursor: 'pointer'
                }}
              >
                Удалить
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default REObjectList;