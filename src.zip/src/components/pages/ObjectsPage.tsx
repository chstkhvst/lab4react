import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { REObjectContext } from '../../context/REObjectContext';
import { useAuth } from '../../context/AuthContext';
import REObjectList from '../REObjectList';

const ObjectsPage = () => {
  const navigate = useNavigate();
  const context = useContext(REObjectContext);
  const { user } = useAuth();
  
  if (!context) return <div>Контекст не загружен</div>;

  const { reobjects, deleteREObject } = context;
  const isAdmin = user?.userRole === 'admin';

  return (
    <div>
      <h2>Объекты недвижимости</h2>
      
      {isAdmin && (
        <button 
          onClick={() => navigate('reobjects/add')}
          style={{ marginBottom: '20px' }}
        >
          Добавить новый объект
        </button>
      )}

      <REObjectList 
        objects={reobjects}
        onDelete={isAdmin ? deleteREObject : undefined}
      />
    </div>
  );
};

export default ObjectsPage;