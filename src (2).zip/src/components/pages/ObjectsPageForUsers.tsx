import React, { useContext } from 'react';
import { Container, Typography, Button } from '@mui/material';
import REObjectList from '../REObjectList';
import { REObjectContext } from '../../context/REObjectContext';
import { Link } from 'react-router-dom';

const ObjectsPageForUsers: React.FC = () => {
  const context = useContext(REObjectContext);

  if (!context) {
    return <Typography>Контекст не найден</Typography>;
  }

  const { reobjects } = context; // Берем только reobjects

  return (
    <Container sx={{ mt: 6 }}>
      <Typography variant="h4" gutterBottom>
        Объекты недвижимости
      </Typography>
      <REObjectList 
        objects={reobjects}
      />
    </Container>
  );
};

export default ObjectsPageForUsers;
