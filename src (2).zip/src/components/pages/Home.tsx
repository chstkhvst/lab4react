import React from 'react';
import { Container, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Home: React.FC = () => {
  const navigate = useNavigate();

  return (
    <Container sx={{ mt: 6 }}>
      <Typography variant="h3" gutterBottom>
        Главная
      </Typography>
      <Button variant="contained" color="primary" onClick={() => navigate('/objects-for-users')}>
        Перейти к объектам
      </Button>
    </Container>
  );
};

export default Home;
