import React, { useContext } from 'react';
import { Container, Typography, Button } from '@mui/material';
import REObjectList from '../REObjectList';
import { REObjectContext } from '../../context/REObjectContext';
import { useAuth, UserRole } from '../../context/AuthContext';
import { useNavigate } from "react-router-dom"

const ObjectPage: React.FC = () => {
  const context = useContext(REObjectContext);
  const { user } = useAuth();
  const navigate = useNavigate()

  if (!context) {
    return <Typography>Контекст не найден</Typography>;
  }

  const { reobjects, deleteREObject } = context;

  // // Проверяем, является ли пользователь администратором
  // if (user?.userRole !== UserRole.Admin) {
  //   return <Typography>У вас нет доступа к этой странице.</Typography>;
  // }

  return (
    <Container sx={{ mt: 6 }}>
      <Typography variant="h4" gutterBottom>
        Список объектов недвижимости
      </Typography>
      <Button variant="contained" onClick={() => navigate("/objects/add")}>
        Добавить новый объект
      </Button>
      <REObjectList 
        objects={reobjects} 
        onDelete={deleteREObject} 
      />
    </Container>
  );

};

export default ObjectPage;
